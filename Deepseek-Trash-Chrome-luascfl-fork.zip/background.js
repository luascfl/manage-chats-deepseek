chrome.runtime.onInstalled.addListener(() => {
    console.log("Minha extensão foi instalada!");
  });
